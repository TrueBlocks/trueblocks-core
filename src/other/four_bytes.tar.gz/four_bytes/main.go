package main

import "github.com/TrueBlocks/trueblocks-core/src/other/four_bytes/cmd"

func main() {
	cmd.Execute()
}
