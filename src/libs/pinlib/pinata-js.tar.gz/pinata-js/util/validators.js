import isIPFS from 'is-ipfs';
