/*
userPinPolicy(newPinPolicy)

Url:
  https://api.pinata.cloud/pinning/userPinPolicy

Send:
  header_with_keys
  newPinPolicy
    list of regions (requires at least one region)
      id one of [FRA1, NYC1] (required)
      desiredReplicationCount (max 2) required === 1 or === 2

Returns:
  "OK" REST 200 status
*/
