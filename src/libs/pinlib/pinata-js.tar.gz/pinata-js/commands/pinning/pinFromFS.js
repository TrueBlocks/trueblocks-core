/*
pinFromFs(sourcePath, options);

Url:
  https://api.pinata.cloud/pinning/pinFileToIPFS

Send:
  header_with_keys
  sourcePath
  options
    metaDataOptions
      name (optional string)
      keyvalues: list of up to 10 key/value pairs (user defined)
        key/value
    options
      cidVersion: 0 or 1 (optional)
      wrapWithDirectory: boolean (optional)
      hostNodes: array of isIPFS.peerMultiaddrs (optional)

Returns:
  "OK" REST 200 status

Pseudo Code:
  validate options.pinataMetadata
  validate options.pinataOptions
  forEveryFileInFolder(
    if metadata, add metadata to request
    if options, add options to request
    add file: filePath to request
    send request
  )
*/
