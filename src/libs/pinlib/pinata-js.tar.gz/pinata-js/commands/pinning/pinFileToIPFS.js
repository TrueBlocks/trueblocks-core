/*
pinFileToIPFS(hashToUnpin);
(also used to pin directories)

Url:
  https://api.pinata.cloud/pinning/pinFileToIPFS

Type:
  POST
  
Send:
  header_with_keys
  list of file: path records
  hashToUnpin (cannot be empty, must be a valid IPFS hash)
    pinataMetadata
      name (optional string)
      keyvalues: list of up to 10 key/value pairs (user defined)
        key/value pairs
    pinataOptions
      cidVersion: 0 or 1 (optional)
      wrapWithDirectory: boolean (optional)
      customPinPolicy
        list of regions (requires at least one region)
          id one of [FRA1, NYC1] (required)
          desiredReplicationCount (max 2) required === 1 or === 2

Response:
  {
    IpfsHash: This is the IPFS multi-hash provided back for your content,
    PinSize: This is how large (in bytes) the content you just pinned is,
    Timestamp: This is the timestamp for your content pinning (represented in ISO 8601 format)
  }

Returns:
  "OK" REST 200 status

Uploading direcories:
  Provide an array of files and relative file paths for each file in the directory
  It's important that each path begins with the "base" directory that is being uploaded.

*/
