/*
hashPinPolicy(ipfsPinHash);

Url:
  https://api.pinata.cloud/pinning/hashPinPolicy/${ipfsPinHash}

Type:
  PUT

Send:
  header_with_keys
  ipfsPinHash: (the hash of the content you with to change the pin policy for),
  newPinPolicy: (pin policy for this hash)

Returns:
  "OK" REST 200 status
*/
