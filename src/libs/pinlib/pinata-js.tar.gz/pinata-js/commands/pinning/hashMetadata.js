/*
hashMetadata(ipfsPinHash);

Url:
  https://api.pinata.cloud/pinning/hashMetadata/${ipfsPinHash}

Type:
  PUT

Send:
  Content-Type: application/json
  header_with_keys
  ipfsPinHash: (the hash of the content you with to change the pin policy for),
  name: (optional) - A new name for Pinata to associate with the hash provided,
  keyvalues: (optional) - The updated keyvalues you want associated with the hash provided
    newKey: 'newValue', //this adds a keyvalue pair
    existingKey: 'newValue' //this modifies the value of an existing key if that key already exists
    existingKeyToRemove: null //this removes a keyvalue pair

Returns:
  "OK" REST 200 status
*/
