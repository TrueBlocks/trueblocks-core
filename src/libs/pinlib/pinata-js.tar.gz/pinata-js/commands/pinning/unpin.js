/*
unpin(hashToUnpin);

Url:
  https://api.pinata.cloud/pinning/unpin/${hashToUnpin}

Send:
  header_with_keys
  hashToUnpin (cannot be empty, must be a valid IPFS hash)

Returns:
  "OK" REST 200 status
*/
