/*
testAuthentication();

Url:
  https://api.pinata.cloud/data/testAuthentication

Send:
  header_with_keys

Returns:
  "OK" REST 200 status
*/
