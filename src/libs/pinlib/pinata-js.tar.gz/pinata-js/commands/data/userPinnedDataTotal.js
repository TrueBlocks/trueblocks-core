userPinnedDataTotal
Endpoint
https://api.pinata.cloud/data/userPinnedDataTotal

Description
This endpoint returns the total combined size for all content that you've pinned through Pinata

Type
GET

Headers
pinata_api_key: (put your personal pinata api key here)

pinata_secret_api_key: (put your personal pinata secret api key here)

Request Parameters
There are no request parameters for this endpoint.

Response
The response for this call will include the following values:

• pin_count - The number of pins you currently have pinned with Pinata

• pin_size_total - The total size of all unique content you have pinned with Pinata (expressed in bytes).

• pin_size_with_replications_total - The total size of all content you have pinned with Pinata. This value is derived by multiplying the size of each piece of unique content by the number of times that content is replicated.

This value will be expressed in bytes

Postman Example:
Postman Example
JavaScript with axios example:
In the javascript example below, we pass in our API keys from elsewhere (hopefully in a secure way).

const axios = require('axios');

export const userPinList = (pinataApiKey, pinataSecretApiKey) => {
    const url = `https://api.pinata.cloud/data/userPinnedDataTotal`;
    return axios
        .get(url, {
            headers: {
                'pinata_api_key': pinataApiKey,
                'pinata_secret_api_key': pinataSecretApiKey
            }
        })
        .then(function (response) {
            //handle response here
        })
        .catch(function (error) {
            //handle error here
        });
};
Have a question? Or a suggestion on how to make Pinata better? We'd love to hear from you!

Send us an email at team@pinata.cloud and we'll see how we can help.



import axios from 'axios';

export default function userPinnedDataTotal(pinataApiKey, pinataSecretApiKey) {
  let endpoint = `https://api.pinata.cloud/data/userPinnedDataTotal`;

  return new Promise((resolve, reject) => {
    axios
      .get(endpoint, {
        withCredentials: true,
        headers: {
          pinata_api_key: pinataApiKey,
          pinata_secret_api_key: pinataSecretApiKey,
        },
      })
      .then(function (result) {
        if (result.status !== 200) {
          reject(new Error(`unknown server response while attempting to retrieve pinned data total: ${result}`));
        }
        resolve(result.data);
      })
      .catch(function (error) {
        //  handle error here
        if (error && error.response && error.response && error.response.data && error.response.data.error) {
          reject(new Error(error.response.data.error));
        } else {
          reject(error);
        }
      });
  });
}
