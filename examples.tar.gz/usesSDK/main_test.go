package main

import "testing"

// UsesSDK is a simple function that calls the SDK
func TestUserSDK(t *testing.T) {
	main()
}
