package main

import (
	"fmt"
	"io"
	"net/http"
)

func main() {
	url := "https://api.pinata.cloud/data/userPinnedDataTotal"
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Add("accept", "application/json")
	if res, err := http.DefaultClient.Do(req); err != nil {
		fmt.Println(err)
	} else {
		defer res.Body.Close()
		body, _ := io.ReadAll(res.Body)
		fmt.Println(string(body))
	}
}
